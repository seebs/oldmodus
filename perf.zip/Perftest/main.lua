text = display.newText("test", 10, 10, 750, 0, native.defaultFont, 40)
text:setReferencePoint(display.CenterReferencePoint)
text.x = 384
text.y = 512
